var express = require("express");
var app = express();
var http = require("http");
var path=require("path");
var bodyparser=require('body-parser');
app.use(bodyparser.urlencoded({ extended: false }));

app.get("/",(req,res)=> 
         res.sendFile(path.join(__dirname ,"index.html"))
      );
app.post("/hello",(req,res)=> 
        {
        res.write('<h1>Hello , ' + req.body.nm + "</h1>");
        res.end();});

app.post("/add",(req,res)=> 
        {
        var sum  = Number(req.body.n1) + parseInt(req.body.n2);
        res.write('<h1>Sum =  ' + sum + "</h1>");
        res.end();});
        
app.get("*",(req,res)=> 
        {
        res.write('Please Check the URL again -> 404');
        res.end();});
http.createServer(app)
    .on("listening",()=>console.log("Listening on 8085"))
    .listen(8085);

