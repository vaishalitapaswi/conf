var express = require("express");
var app = express();
var http = require("http");
var path=require("path");
app.get("/",(req,res)=> 
         res.sendFile(path.join(__dirname ,"index.html"))
      );
app.get("/hello",(req,res)=> 
        {
        res.write('<h1>Hello , ' + req.query.nm + "</h1>");
        res.end();});

app.get("/add",(req,res)=> 
        {
        var sum  = Number(req.query.n1) + parseInt(req.query.n2);
        res.write('<h1>Sum =  ' + sum + "</h1>");
        res.end();});
        
app.get("*",(req,res)=> 
        {
        res.write('Please Check the URL again -> 404');
        res.end();});
http.createServer(app).listen(8085);

