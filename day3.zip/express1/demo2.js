var express = require("express");
var app = express();
var http = require("http");
var path="c:/siemens/express1/"
app.get("/",(req,res)=> 
         res.sendFile(path+"index.html")
      );
app.get("/hello/:nm",(req,res)=> 
        {
        res.write('<h1>Hello , ' + req.params.nm + "</h1>");
        res.end();});

app.get("/add/:n1/:n2",(req,res)=> 
        {
        var sum  = Number(req.params.n1) + parseInt(req.params.n2);
        res.write('<h1>Sum =  ' + sum + "</h1>");
        res.end();});
        
app.get("*",(req,res)=> 
        {
        res.write('Please Check the URL again -> 404');
        res.end();});
http.createServer(app).listen(8085);

