var express = require("express");
var app = express();
var http = require("http");
var path="c:/siemens/express1/"
app.get("/",(req,res)=> 
         res.sendFile(path+"index.html")
      );
app.post("/hello",(req,res)=> 
        {
        res.write('Hello , NAME ');
        res.end();});
app.get("*",(req,res)=> 
        {
        res.write('Please Check the URL again -> 404');
        res.end();});
http.createServer(app).listen(8085);

