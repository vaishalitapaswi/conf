var mdb = require('mongoose');
var EmpModel = mdb.model('EmpModel', 
{ empno: Number, ename: String,salary :Number });
var dburl = "mongodb://localhost/test";
function add(emp){
    console.log("add invoked..");
    mdb.connect(dburl);
    var emp1 = new EmpModel(emp);
    emp1.save((err)=>{
        if (err){
            console.log("Some Problem...");
            console.log(err);
        }
        else{
            console.log("no problem....");
        }
         mdb.disconnect();
    });
       console.log(emp);
    
}
function list(req,res){
    console.log("list invoked...")
    mdb.connect(dburl);
    EmpModel.find((err,objarr)=>{
        mdb.disconnect();
        if(err)
           { console.log("Errorr...");
            return res.end("<h1>No Data</h1>");
            }
        if(objarr)
           {
            console.log(objarr.length);
            res.write("<table bgcolor='cyan' border='1'>");
            for(var i = 0; i< objarr.length;i++){
                res.write("<tr><td>" + objarr[i].empno +"</td>"
                + "<td>" + objarr[i].ename +"</td>"
                +"<td>" + objarr[i].salary +"</td></tr>"
                );
               
            }
            res.end("</table>"); 
            } 
    });
}

exports.add=add;
exports.list=list;

