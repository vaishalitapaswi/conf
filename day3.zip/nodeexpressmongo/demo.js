var express = require("express");
var http = require("http");
var path=require("path");
var bodyparser=require('body-parser');
var empmgr = require('./empmgr');

var app = express();
app.use(bodyparser.urlencoded({ extended: false }));

app.get("/",(req,res)=> 
         res.sendFile(path.join(__dirname ,"index.html"))
      );
app.get("/insert.html",(req,res)=> 
         res.sendFile(path.join(__dirname ,"insert.html"))
        );
app.post("/insert",(req,res)=> 
        {
          var empobj={};
           empobj.empno = Number(req.body.empno);
           empobj.ename = req.body.ename;
           empobj.salary = Number(req.body.salary);
           console.log(empobj);
           empmgr.add(empobj);
          res.sendFile(path.join(__dirname ,"index.html"))
        });
app.get("/list",(req,res)=> 
        {
        empmgr.list(req,res);
        });
app.get("*",(req,res)=> 
        {
        res.write('Please Check the URL again -> 404');
        res.end();});
http.createServer(app)
    .on("listening",()=>console.log("Listening on 8085"))
    .listen(8085);

