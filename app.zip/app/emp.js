"use strict";
var Emp = (function () {
    function Emp() {
    }
    return Emp;
}());
exports.Emp = Emp;
//# sourceMappingURL=emp.js.map