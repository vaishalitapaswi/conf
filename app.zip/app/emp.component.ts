import { Component } from '@angular/core';
import { Emp } from './emp'
@Component({
  selector: 'emp',
  templateUrl: './emp.html'
})
export class EmpComponent  { 
  e:Emp= new Emp();
  name = 'Angular'; 
  emparr= new Array();

public add():void{
  this.emparr.push(this.e);
  console.log(this.emparr);
  this.e = new Emp();
}
}
