console.log("in demo3");
var v = require('./demo1');
v.m1();
//var v1 = require('./demo');
exports.m1 = m1;