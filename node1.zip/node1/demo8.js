var http = require('http');
var url = require('url') ;
http.createServer(function (req, res) {
  console.log(req.url);
  if (req.url=="/" )
  {
      res.write('<form action="" method="get">Name : <input type="text" name="nm" value="Vaishali" /></br><input type="submit" value="Submit" /></form>');
      res.end();
  }
 else  if (req.url=="/favicon.ico" )
  {
      res.write('<form action="" method="get">Name : <input type="text" name="nm" value="Vaishali" /></br><input type="submit" value="Submit" /></form>');
      res.end();
  }
  else{
  var queryObject = url.parse(req.url,true).query;
  console.log(queryObject);
  res.writeHead(200);
  res.write("<h1>Hello,  " + queryObject.nm + "</h1>");
  
  res.end();
  }
}).listen(8085);
