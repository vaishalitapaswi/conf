console.log(222+222);
console.log("in demo1.js");

function m1()
{
    console.log("in m1");

}
export.m1 = m1;