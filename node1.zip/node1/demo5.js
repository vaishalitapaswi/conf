var http = require('http');

var server = http.createServer((request, response) => {
    console.log("in server method....");
    console.log(request.url);
    if (request.url == "/") {
        response.write("<h1>Index Page<br/>" +
            "<a href='link1'>Link1</a><br/>" +
            "<a href='link2'>Link2</a></h1>");
  }
    if (request.url == "/link1") {
        response.write("<h1>In Link1</h1>");
    }
    if (request.url == "/link2") {
        response.write("<h1>In Link2</h1>");
    }
    response.end();
});

server.listen(5000);
