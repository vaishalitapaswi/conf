console.log("demo4Helper....");
function add(n1, n2)
{
    return n1+n2;
}
function sub(n1, n2)
{
    return n1-n2;
}
function multiply(n1, n2)
{
    return n1*n2;
}
function divide(n1, n2)
{
    return n1/n2;
}
var ops = {};
ops.addition=add;
ops.subtraction=sub;
ops.muliplication=multiply;

module.exports.ops = ops;

// require('os')

