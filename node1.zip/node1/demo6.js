var http = require('http');
var server = http.createServer();
var reqcount = 0;
var currentrequests = 0;
server.on("request",
(request, response) => {
    currentrequests++;
    request.on("end",()=>{
        console.log("end");
        currentrequests--;
    });

    console.log("in requst - " + ++reqcount);
    response.write("<h1>HelloWorld</h1>");
    response.write("<h1>Total No of Requests = " + reqcount);
    response.write("<h1>Current  No of Requests = " + currentrequests);
    response.end();
});


console.log("before server on listening....")
server.on("listening",()=>{
    console.log("Server is listening....");
});
console.log("before listen....")
server.listen(5000);
