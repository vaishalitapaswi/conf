v = "Abc";
console.log("v ="  + v);
console.log("sum of 10,20 is " +  add(true,20));
console.log("sub of 100,20 is " +  sub(100,20));
console.log("multiplication of 10,20 is " +  multiply(10,20));
console.log("division of 100,20 is " +  divide(100,20));

function add(n1, n2)
{
    console.log("v in add is ="  + v);
    return n1+n2;
}
function sub(n1, n2)
{
    return n1-n2;
}
function multiply(n1, n2)
{
    return n1*n2;
}
function divide(n1, n2)
{
    return n1/n2;
}
